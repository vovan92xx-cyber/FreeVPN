package ru.freevpn.client;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 41;
    private static final int VPN_PERMISSION = 42;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<File> profiles = new ArrayList<>();
    private GoBackend backend;
    private Spinner profileSpinner;
    private TextView status;
    private Button connectButton;
    private Button disconnectButton;
    private Tunnel tunnel;
    private Config pendingConfig;

    private final Tunnel wireGuardTunnel = new Tunnel() {
        @Override public String getName() { return "FreeVPN"; }
        @Override public void onStateChange(State state) {
            runOnUiThread(() -> showStatus(state == State.UP
                    ? "Подключено (туннель запущен)"
                    : "Отключено"));
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backend = new GoBackend(this);
        tunnel = wireGuardTunnel;
        buildUi();
        refreshProfiles();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(22));
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(0xFFF4F7FB);

        TextView title = new TextView(this);
        title.setText("FREE VPN");
        title.setTextSize(30);
        title.setTextColor(0xFF14243A);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("WireGuard • Android");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF607087);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.bottomMargin = dp(28);
        page.addView(subtitle, subParams);

        status = new TextView(this);
        status.setText("Отключено");
        status.setTextSize(20);
        status.setTextColor(0xFF14243A);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.bottomMargin = dp(22);
        page.addView(status, statusParams);

        TextView profileLabel = new TextView(this);
        profileLabel.setText("Выбери конфигурацию сервера");
        profileLabel.setTextSize(15);
        profileLabel.setTextColor(0xFF33445C);
        page.addView(profileLabel, matchWrap());

        profileSpinner = new Spinner(this);
        LinearLayout.LayoutParams spinnerParams = matchWrap();
        spinnerParams.bottomMargin = dp(18);
        page.addView(profileSpinner, spinnerParams);

        Button importButton = new Button(this);
        importButton.setText("Импортировать .conf");
        importButton.setOnClickListener(v -> chooseConfig());
        page.addView(importButton, matchWrap());

        connectButton = new Button(this);
        connectButton.setText("ПОДКЛЮЧИТЬС");
        connectButton.setOnClickListener(v -> requestConnect());
        LinearLayout.LayoutParams connectParams = matchWrap();
        connectParams.topMargin = dp(16);
        page.addView(connectButton, connectParams);

        disconnectButton = new Button(this);
        disconnectButton.setText("ОТКЛЮЧИТЬСЯ");
        disconnectButton.setOnClickListener(v -> disconnect());
        page.addView(disconnectButton, matchWrap());

        TextView note = new TextView(this);
        note.setText("Нужен действующий файл WireGuard .conf. "
                + "Приложение не содержит собственных VPN-серверов. "
                + "Конфигурации хранятся только в памяти приложения на этом телефоне.");
        note.setTextSize(12);
        note.setTextColor(0xFF66758A);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(26);
        page.addView(note, noteParams);

        setContentView(page);
    }

    private void chooseConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_CONFIG);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CONFIG && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                if (in == null) throw new IllegalStateException("Не удалось открыть файл");
                String configText = readAll(in);
                // Parse before saving so invalid files are rejected.
                Config.parse(new BufferedReader(new StringReader(configText)));
                String name = data.getData().getLastPathSegment();
                if (name == null || name.trim().isEmpty()) name = "WireGuard";
                name = name.replaceAll("[^A-Za-zА-Яа-я0-9._-]", "_");
                if (!name.toLowerCase().endsWith(".conf")) name += ".conf";
                File target = new File(getFilesDir(), System.currentTimeMillis() + "_" + name);
                try (java.io.FileOutputStream out = new java.io.FileOutputStream(target)) {
                    out.write(configText.getBytes(StandardCharsets.UTF_8));
                }
                refreshProfiles();
                Toast.makeText(this, "Конфигурация импортирована", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Ошибка конфигурации: " + safeMessage(e), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == VPN_PERMISSION && resultCode == RESULT_OK) {
            startTunnel();
        } else if (requestCode == VPN_PERMISSION) {
            showStatus("Разрешение VPN не предоставлено");
        }
    }

    private void requestConnect() {
        if (profiles.isEmpty() || profileSpinner.getSelectedItemPosition() < 0) {
            Toast.makeText(this, "Сначала импортируй файл .conf", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            File selected = profiles.get(profileSpinner.getSelectedItemPosition());
            String text;
            try (InputStream in = new FileInputStream(selected)) {
                text = readAll(in);
            }
            pendingConfig = Config.parse(new BufferedReader(new StringReader(text)));
            Intent permissionIntent = VpnService.prepare(this);
            if (permissionIntent != null) startActivityForResult(permissionIntent, VPN_PERMISSION);
            else startTunnel();
        } catch (Exception e) {
            showStatus("Ошибка: " + safeMessage(e));
        }
    }

    private void startTunnel() {
        if (pendingConfig == null) return;
        connectButton.setEnabled(false);
        showStatus("Подключение...");
        executor.execute(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.UP, pendingConfig);
                runOnUiThread(() -> showStatus("Туннель запущен. Проверяй доступ к интернету."));
            } catch (Exception e) {
                runOnUiThread(() -> showStatus("Не удалось подключиться: " + safeMessage(e)));
            } finally {
                runOnUiThread(() -> connectButton.setEnabled(true));
            }
        });
    }

    private void disconnect() {
        executor.execute(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null);
                runOnUiThread(() -> showStatus("Отключено"));
            } catch (Exception e) {
                runOnUiThread(() -> showStatus("Ошибка отключения: " + safeMessage(e)));
            }
        });
    }

    private void refreshProfiles() {
        profiles.clear();
        File[] files = getFilesDir().listFiles((dir, name) -> name.endsWith(".conf"));
        if (files != null) {
            java.util.Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            for (File f : files) profiles.add(f);
        }
        List<String> labels = new ArrayList<>();
        for (File f : profiles) labels.add(f.getName().replaceFirst("^\\d+_", ""));
        if (labels.isEmpty()) labels.add("Нет импортированных серверов");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        profileSpinner.setAdapter(adapter);
    }

    private void showStatus(String text) {
        status.setText(text);
    }

    private String readAll(InputStream in) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) out.append(line).append('\n');
        return out.toString();
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null ? e.getClass().getSimpleName() : message;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
